#!/usr/bin/env python3
"""I-4 Sistem Operasi (Kelas D) - Flash sale overselling: EKSPERIMEN TAMBAHAN: KUNCI PARSIAL (sengaja salah).

Hanya untuk analisis: lock dipasang pada cek stok saja dan pada pengurangan stok
saja (dua blok terpisah). Keduanya atomik sendiri-sendiri, tetapi keputusan dari
cek tidak dilindungi sampai pengurangan, sehingga race condition TETAP terjadi.
Bukan versi perbaikan; jangan dikumpulkan sebagai solusi.

Pemakaian:
  python3 eksperimen_kunci_parsial.py                       # 100 eksekusi, 10 pembeli, jeda 1 ms
  python3 eksperimen_kunci_parsial.py --jeda-ms 0           # tanpa jeda buatan
  python3 eksperimen_kunci_parsial.py --eksekusi 1 --detail # satu eksekusi, tampilkan daftar pembeli
"""
import argparse
import threading
import time

p = argparse.ArgumentParser(description="Flash sale dengan kunci parsial (salah)")
p.add_argument("--stok", type=int, default=1, help="stok awal produk")
p.add_argument("--pembeli", type=int, default=10, help="jumlah thread pembeli")
p.add_argument("--eksekusi", type=int, default=100, help="jumlah pengulangan percobaan")
p.add_argument("--jeda-ms", type=float, default=1.0,
               help="jeda buatan antara cek dan kurangi stok (ms); 0 = tanpa sleep sama sekali")
p.add_argument("--yield-gil", action="store_true",
               help="dengan --jeda-ms 0: panggil time.sleep(0) (hanya melepas GIL, tanpa menunggu)")
p.add_argument("--detail", action="store_true", help="cetak pembeli berhasil/gagal tiap eksekusi")
arg = p.parse_args()


def satu_eksekusi():
    """Menjalankan satu flash sale; mengembalikan (berhasil, gagal, stok_akhir)."""
    data = {"stok": arg.stok}          # DATA BERSAMA yang diakses semua thread
    berhasil, gagal = [], []           # catatan hasil (list.append aman di CPython)
    kunci_stok = threading.Lock()
    mulai_bersama = threading.Barrier(arg.pembeli)

    def pembeli(nomor):
        mulai_bersama.wait()           # semua pembeli mulai hampir bersamaan
        with kunci_stok:               # lock hanya untuk membaca stok
            ada_stok = data["stok"] > 0
        if ada_stok:                   # keputusan dipakai SETELAH lock dilepas
            if arg.jeda_ms > 0:
                time.sleep(arg.jeda_ms / 1000)   # simulasi verifikasi pembayaran
            elif arg.yield_gil:
                time.sleep(0)                    # hanya memberi kesempatan thread lain berjalan
            with kunci_stok:           # lock lagi hanya untuk mengurangi stok
                data["stok"] = data["stok"] - 1
            berhasil.append(nomor)
        else:
            gagal.append(nomor)

    threads = [threading.Thread(target=pembeli, args=(i + 1,)) for i in range(arg.pembeli)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    return sorted(berhasil), sorted(gagal), data["stok"]


print(f"VERSI: KUNCI PARSIAL (salah, hanya untuk analisis) | stok awal={arg.stok} pembeli={arg.pembeli} "
      f"eksekusi={arg.eksekusi} jeda={arg.jeda_ms} ms yield_gil={arg.yield_gil}")
print("No | Berhasil | Gagal | Stok akhir | Overselling | Konsisten")
jumlah_oversell = jumlah_konsisten = total_berhasil = 0
for n in range(1, arg.eksekusi + 1):
    berhasil, gagal, stok_akhir = satu_eksekusi()
    oversell = len(berhasil) > arg.stok
    konsisten = (not oversell) and stok_akhir >= 0 and stok_akhir == arg.stok - len(berhasil)
    jumlah_oversell += oversell
    jumlah_konsisten += konsisten
    total_berhasil += len(berhasil)
    print(f"{n:3d} | {len(berhasil):8d} | {len(gagal):5d} | {stok_akhir:10d} | "
          f"{'YA' if oversell else 'tidak':11s} | {'ya' if konsisten else 'TIDAK'}")
    if arg.detail:
        print(f"      pembeli berhasil: {berhasil}")
        print(f"      pembeli gagal   : {gagal}")
print("-" * 60)
print(f"RINGKASAN: {arg.eksekusi} eksekusi | overselling {jumlah_oversell} kali | "
      f"konsisten {jumlah_konsisten} kali | total transaksi berhasil {total_berhasil} "
      f"(seharusnya maks {arg.stok * arg.eksekusi})")
