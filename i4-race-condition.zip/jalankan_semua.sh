#!/usr/bin/env bash
# Menjalankan seluruh eksperimen I-4 dengan kondisi uji yang sama untuk kedua versi.
# Pemakaian: bash jalankan_semua.sh        (hasil tersimpan di folder hasil/)
set -e
cd "$(dirname "$0")/src"
H=../hasil; mkdir -p $H
{ echo "Tanggal: $(date -Iseconds)"; echo "Kernel: $(uname -r)"; python3 --version; echo "vCPU: $(nproc)"
  lscpu | grep 'Model name'; free -m | sed -n 2p
  python3 -c "import sys;print('GIL aktif:', sys._is_gil_enabled(), '| switch interval:', sys.getswitchinterval(), 's')"; } > $H/lingkungan.txt
# K1 = jeda 1 ms | K2 = tanpa jeda, hanya time.sleep(0) | K3 = tanpa sleep sama sekali
declare -A OPSI=( [K1]="--jeda-ms 1" [K2]="--jeda-ms 0 --yield-gil" [K3]="--jeda-ms 0" )
for k in K1 K2 K3; do for pb in 2 10 100; do
  for v in sebelum sesudah; do
    python3 flash_sale_$v.py --pembeli $pb ${OPSI[$k]} --eksekusi 100 > $H/${v}_${k}_pembeli${pb}.log
  done
done; done
for k in K1 K2 K3; do
  python3 eksperimen_kunci_parsial.py --pembeli 10 ${OPSI[$k]} --eksekusi 100 > $H/parsial_${k}_pembeli10.log
done
# uji panjang tanpa jeda sama sekali (K3), 1000 eksekusi x 100 pembeli
for v in sebelum sesudah; do
  python3 flash_sale_$v.py --pembeli 100 --jeda-ms 0 --eksekusi 1000 > $H/${v}_K3_pembeli100_1000x.log
done
# satu eksekusi dengan daftar pembeli (untuk bukti rinci)
for v in sebelum sesudah; do
  python3 flash_sale_$v.py --pembeli 10 --jeda-ms 1 --eksekusi 1 --detail > $H/${v}_detail_1x.log
done
echo selesai
