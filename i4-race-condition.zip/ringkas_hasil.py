#!/usr/bin/env python3
"""Merangkum log di folder hasil/ menjadi hasil/ringkasan.json (untuk tabel laporan)."""
import glob, json, os, re
out = {}
for f in sorted(glob.glob("hasil/*_K*_pembeli*.log")):
    nama = os.path.basename(f)[:-4]
    baris = [l for l in open(f).read().splitlines() if re.match(r"\s*\d+ \|", l)]
    ber, stok, over = [], [], 0
    for l in baris:
        c = [x.strip() for x in l.split("|")]
        ber.append(int(c[1])); stok.append(int(c[3])); over += c[4] == "YA"
    out[nama] = dict(eksekusi=len(baris), overselling=over, konsisten=len(baris) - sum(
        1 for b, s in zip(ber, stok) if not (b <= 1 and s == 1 - b and s >= 0)),
        total_berhasil=sum(ber), berhasil_min=min(ber), berhasil_maks=max(ber),
        stok_min=min(stok), stok_maks=max(stok))
json.dump(out, open("hasil/ringkasan.json", "w"), indent=1)
for k, v in out.items(): print(k, v)
